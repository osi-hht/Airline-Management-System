from django.apps import AppConfig


class AirlineAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'airline_app'
