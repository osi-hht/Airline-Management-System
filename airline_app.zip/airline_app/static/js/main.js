document.addEventListener('DOMContentLoaded', function() {
    // Navbar scroll behavior
    const navbar = document.getElementById('mainNav');
    const mobileMenuBtn = document.getElementById('mobileMenuBtn');
    const mobileMenu = document.getElementById('mobileMenu');
    
    if (navbar) {
        // Set initial transparency based on scroll position
        updateNavbarTransparency();
        
        // Listen for scroll events
        window.addEventListener('scroll', function() {
            updateNavbarTransparency();
        });
    }
    
    function updateNavbarTransparency() {
        if (window.scrollY > 50) {
            navbar.classList.add('nav-scrolled');
            navbar.querySelectorAll('a:not(.btn-primary)').forEach(item => {
                item.classList.remove('text-white');
                item.classList.add('text-airline-blue-900');
            });
        } else {
            navbar.classList.remove('nav-scrolled');
            navbar.querySelectorAll('a:not(.btn-primary)').forEach(item => {
                item.classList.add('text-white');
                item.classList.remove('text-airline-blue-900');
            });
        }
    }
    
    // Mobile menu toggle
    if (mobileMenuBtn && mobileMenu) {
        mobileMenuBtn.addEventListener('click', function() {
            mobileMenu.classList.toggle('hidden');
        });
    }
    
    // Smooth scrolling for anchor links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            const targetId = this.getAttribute('href');
            if (targetId === '#') return;
            
            const targetElement = document.querySelector(targetId);
            if (targetElement) {
                e.preventDefault();
                
                window.scrollTo({
                    top: targetElement.offsetTop - 100,
                    behavior: 'smooth'
                });
                
                // Close mobile menu if open
                if (mobileMenu && !mobileMenu.classList.contains('hidden')) {
                    mobileMenu.classList.add('hidden');
                }
            }
        });
    });
    
    // Add fade-in animation to elements as they scroll into view
    const fadeElements = document.querySelectorAll('.fade-in-element');
    
    if (fadeElements.length > 0 && 'IntersectionObserver' in window) {
        const fadeInObserver = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('fade-in');
                    fadeInObserver.unobserve(entry.target);
                }
            });
        }, { threshold: 0.1 });
        
        fadeElements.forEach(element => {
            fadeInObserver.observe(element);
        });
    } else {
        // Fallback for browsers that don't support IntersectionObserver
        fadeElements.forEach(element => {
            element.classList.add('fade-in');
        });
    }
});